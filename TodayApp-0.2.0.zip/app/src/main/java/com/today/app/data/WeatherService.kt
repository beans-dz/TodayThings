package com.today.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object WeatherService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun get(city: String?): WeatherData? = withContext(Dispatchers.IO) {
        runCatching {
            var lat = Double.NaN
            var lon = Double.NaN
            var name = city

            if (!city.isNullOrBlank()) {
                val geo = fetchJson(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" +
                        URLEncoder.encode(city, "UTF-8") + "&count=1&language=zh"
                )
                val arr = geo?.optJSONArray("results")
                if (arr != null && arr.length() > 0) {
                    val o = arr.getJSONObject(0)
                    lat = o.optDouble("latitude", Double.NaN)
                    lon = o.optDouble("longitude", Double.NaN)
                    name = o.optString("name", city)
                }
            }

            if (lat.isNaN() || lon.isNaN()) {
                val ip = fetchJson("https://ipinfo.io/json")
                val loc = ip?.optString("loc")
                if (loc != null && loc.contains(",")) {
                    val parts = loc.split(",")
                    lat = parts[0].toDoubleOrNull() ?: Double.NaN
                    lon = parts[1].toDoubleOrNull() ?: Double.NaN
                    name = ip.optString("city", "")
                }
            }

            if (lat.isNaN() || lon.isNaN()) return@runCatching null

            val w = fetchJson(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&timezone=auto"
            )
            val cur = w?.optJSONObject("current")
            if (cur == null) null else WeatherData(
                city = name ?: "",
                temp = if (cur.has("temperature_2m")) cur.optDouble("temperature_2m") else null,
                code = cur.optInt("weather_code", -1),
                desc = codeDesc(cur.optInt("weather_code", -1))
            )
        }.getOrNull()
    }

    private fun fetchJson(url: String): JSONObject? = runCatching {
        val req = Request.Builder().url(url).addHeader("User-Agent", "TodayApp/1.0").build()
        client.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) JSONObject(resp.body?.string() ?: "") else null
        }
    }.getOrNull()

    private fun codeDesc(code: Int): String = when (code) {
        0 -> "晴"
        1, 2 -> "大部晴朗"
        3 -> "多云"
        45, 48 -> "雾"
        51, 53, 55 -> "毛毛雨"
        56, 57 -> "冻雨"
        61, 63, 65 -> "雨"
        66, 67 -> "冻雨"
        71, 73, 75 -> "雪"
        77 -> "雪粒"
        80, 81, 82 -> "阵雨"
        85, 86 -> "阵雪"
        95 -> "雷暴"
        96, 99 -> "雷暴伴冰雹"
        else -> "未知"
    }
}
