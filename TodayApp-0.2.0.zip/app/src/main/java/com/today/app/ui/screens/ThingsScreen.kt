package com.today.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.today.app.data.Countdown
import com.today.app.data.Goal
import com.today.app.data.Task
import com.today.app.data.dateLabel
import com.today.app.data.daysUntil
import com.today.app.data.todayStr
import com.today.app.ui.AppViewModel
import com.today.app.ui.components.AnimatedCard
import com.today.app.ui.components.EmptyHint
import com.today.app.ui.components.SectionHeader
import com.today.app.ui.components.StaggerIn
import java.time.Instant
import java.time.ZoneId

private enum class AddType { COUNTDOWN, GOAL, TASK }

@Composable
fun ThingsScreen(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val goals by vm.goals.collectAsStateWithLifecycle()
    val countdowns by vm.countdowns.collectAsStateWithLifecycle()

    var fabExpanded by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf<AddType?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Things", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            }

            item { StaggerIn(0) { SectionHeader("倒计时") } }
            if (countdowns.isEmpty()) {
                item { StaggerIn(1) { EmptyHint("暂无倒计时，点右下角添加") } }
            } else {
                itemsIndexed(countdowns, key = { _, c -> c.id }) { i, c ->
                    StaggerIn(i.coerceAtMost(8)) { CountdownCard(c, onDelete = { vm.deleteCountdown(c.id) }) }
                }
            }

            item { StaggerIn(2) { SectionHeader("每日目标") } }
            if (goals.isEmpty()) {
                item { StaggerIn(3) { EmptyHint("暂无目标，点右下角添加") } }
            } else {
                itemsIndexed(goals, key = { _, g -> g.id }) { i, g ->
                    StaggerIn(i.coerceAtMost(8)) { GoalCard(g, onToggle = { vm.toggleGoalToday(g.id) }, onDelete = { vm.deleteGoal(g.id) }) }
                }
            }

            item { StaggerIn(4) { SectionHeader("今日待办") } }
            val todayTasks = tasks.filter { it.date == todayStr() }
            if (todayTasks.isEmpty()) {
                item { StaggerIn(5) { EmptyHint("今天还没有安排") } }
            } else {
                itemsIndexed(todayTasks, key = { _, t -> t.id }) { i, t ->
                    StaggerIn(i.coerceAtMost(8)) { TaskRow(t, onToggle = { vm.toggleTask(t.id) }, onDelete = { vm.deleteTask(t.id) }) }
                }
            }
        }

        AddFab(
            expanded = fabExpanded,
            onToggle = { fabExpanded = !fabExpanded },
            onPick = {
                addType = it
                fabExpanded = false
            }
        )
    }

    when (addType) {
        AddType.COUNTDOWN -> AddCountdownDialog(
            onDismiss = { addType = null },
            onAdd = { t, d -> vm.addCountdown(t, d); addType = null }
        )
        AddType.GOAL -> AddGoalDialog(
            onDismiss = { addType = null },
            onAdd = { t -> vm.addGoal(t); addType = null }
        )
        AddType.TASK -> AddTaskDialog(
            onDismiss = { addType = null },
            onAdd = { t, time -> vm.addTask(t, time); addType = null }
        )
        null -> {}
    }
}

@Composable
private fun BoxScope.AddFab(
    expanded: Boolean,
    onToggle: () -> Unit,
    onPick: (AddType) -> Unit
) {
    Column(
        Modifier
            .align(Alignment.BottomEnd)
            .padding(end = 22.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.End
    ) {
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(tween(200)) +
                slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { it / 2 } +
                scaleIn(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow), initialScale = 0.7f),
            exit = fadeOut(tween(150)) +
                slideOutVertically(tween(180)) { it / 3 } +
                scaleOut(tween(150), targetScale = 0.7f)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.End
            ) {
                MiniFab("倒计时", Icons.Filled.DateRange) { onPick(AddType.COUNTDOWN) }
                MiniFab("目标", Icons.Filled.CheckCircle) { onPick(AddType.GOAL) }
                MiniFab("待办", Icons.Filled.Check) { onPick(AddType.TASK) }
            }
        }
        Spacer(Modifier.height(12.dp))
        FloatingActionButton(
            onClick = onToggle,
            shape = CircleShape,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White
        ) {
            val angle by animateFloatAsState(
                targetValue = if (expanded) 45f else 0f,
                animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                label = "fabRotate"
            )
            Icon(
                if (expanded) Icons.Filled.Close else Icons.Filled.Add,
                "添加",
                Modifier.graphicsLayer { rotationZ = angle }
            )
        }
    }
}

@Composable
private fun MiniFab(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    ExtendedFloatingActionButton(
        onClick = onClick,
        icon = { Icon(icon, null, Modifier.size(20.dp)) },
        text = { Text(label) },
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddCountdownDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    val dateState = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加倒计时") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    title, { title = it }, Modifier.fillMaxWidth(),
                    label = { Text("名称，如：高考") }, singleLine = true
                )
                Text("选择日期", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                DatePicker(state = dateState, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val millis = dateState.selectedDateMillis
                if (title.isNotBlank() && millis != null) {
                    val d = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                    onAdd(title, d)
                }
            }) { Text("添加") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
private fun AddGoalDialog(
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加目标") },
        text = {
            OutlinedTextField(
                title, { title = it }, Modifier.fillMaxWidth(),
                label = { Text("目标，如：跑步 30 分钟") }, singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) onAdd(title)
            }) { Text("添加") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTaskDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    val timeState = rememberTimePickerState(initialHour = 8, initialMinute = 0, is24Hour = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加待办") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    title, { title = it }, Modifier.fillMaxWidth(),
                    label = { Text("待办，如：开会") }, singleLine = true
                )
                Text("选择时间", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TimePicker(state = timeState, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    val time = "${timeState.hour.toString().padStart(2, '0')}:${timeState.minute.toString().padStart(2, '0')}"
                    onAdd(title, time)
                }
            }) { Text("添加") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
private fun CountdownCard(c: Countdown, onDelete: () -> Unit) {
    val days = daysUntil(c.date)
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.DateRange,
                null,
                Modifier.size(28.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(dateLabel(c.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                if (days > 0) "${days}天" else if (days == 0L) "就是今天" else "已过${-days}天",
                style = MaterialTheme.typography.titleMedium,
                color = if (days in 0L..3L) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(6.dp))
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun GoalCard(g: Goal, onToggle: () -> Unit, onDelete: () -> Unit) {
    val checked = todayStr() in g.checkedDates
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val scale by animateFloatAsState(
                targetValue = if (checked) 1f else 0.92f,
                animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                label = "goalScale"
            )
            Box(
                Modifier
                    .size(40.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(CircleShape)
                    .background(if (checked) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .then(
                        if (checked) Modifier else Modifier.border(
                            2.dp, MaterialTheme.colorScheme.outline, CircleShape
                        )
                    )
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (checked) Icon(Icons.Filled.Check, "打卡", tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    g.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    "已打卡 ${g.checkedDates.size} 天",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun TaskRow(t: Task, onToggle: () -> Unit, onDelete: () -> Unit) {
    val scale by animateFloatAsState(
        targetValue = if (t.done) 1.05f else 1f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "taskScale"
    )
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(14.dp).graphicsLayer { scaleX = scale; scaleY = scale },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (t.done) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .then(
                        if (t.done) Modifier else Modifier.border(
                            2.dp, MaterialTheme.colorScheme.outline, CircleShape
                        )
                    )
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (t.done) Icon(Icons.Filled.Check, null, Modifier.size(16.dp), tint = Color.White)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (t.done) FontWeight.Normal else FontWeight.Medium,
                    color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                if (t.time.isNotBlank()) {
                    Text(t.time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}
