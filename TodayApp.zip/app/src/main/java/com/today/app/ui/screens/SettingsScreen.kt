package com.today.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.today.app.data.DeepSeekClient
import com.today.app.data.RssSource
import com.today.app.ui.AppViewModel
import com.today.app.ui.components.AnimatedCard
import com.today.app.ui.components.EmptyHint
import com.today.app.ui.components.SectionHeader
import com.today.app.ui.components.StaggerIn
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var baseUrl by remember { mutableStateOf(settings.baseUrl) }
    var model by remember { mutableStateOf(settings.model) }
    var politicsCount by remember { mutableStateOf(settings.politicsCount.toString()) }
    var otherCount by remember { mutableStateOf(settings.otherCount.toString()) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var newSourceName by remember { mutableStateOf("") }
    var newSourceUrl by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }

        item { StaggerIn(0) { SectionHeader("������ DeepSeek AI") } }
        item {
            StaggerIn(1) {
                AnimatedCard {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            apiKey, { apiKey = it }, Modifier.fillMaxWidth(),
                            label = { Text("API Key") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                        OutlinedTextField(baseUrl, { baseUrl = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") }, singleLine = true)
                        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("模型名称") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("每日新闻数量", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
                                Text("时政 / 其他", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(Modifier.weight(1f))
                            OutlinedTextField(
                                politicsCount, { politicsCount = it }, Modifier.width(64.dp),
                                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            Text(" / ", Modifier.padding(horizontal = 4.dp))
                            OutlinedTextField(
                                otherCount, { otherCount = it }, Modifier.width(64.dp),
                                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (testing) {
                                CircularProgressIndicator(Modifier.width(18.dp), strokeWidth = 2.dp)
                            }
                            Text(testResult.orEmpty(), Modifier.padding(start = 8.dp), style = MaterialTheme.typography.bodySmall,
                                color = if (testResult?.contains("成功") == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        }
                        Row {
                            Button(
                                enabled = !testing && apiKey.isNotBlank(),
                                onClick = {
                                    testing = true; testResult = null
                                    scope.launch {
                                        val ok = DeepSeekClient.test(baseUrl, apiKey, model)
                                        testResult = if (ok) "✅ 连接成功" else "❌ 连接失败"
                                        testing = false
                                    }
                                }
                            ) { Text("测试连接") }
                            Spacer(Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    vm.saveSettings(
                                        settings.copy(
                                            apiKey = apiKey, baseUrl = baseUrl, model = model,
                                            politicsCount = politicsCount.toIntOrNull() ?: 15,
                                            otherCount = otherCount.toIntOrNull() ?: 5
                                        )
                                    )
                                    testResult = "已保存 ✓"
                                }
                            ) { Text("保存") }
                        }
                    }
                }
            }
        }

        item { StaggerIn(2) { SectionHeader("������ 新闻源（RSS）") } }
        item {
            StaggerIn(3) {
                AnimatedCard {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        settings.rssSources.forEach { s ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(s.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                    Text("${s.category} · ${s.url}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = {
                                    vm.saveSettings(settings.copy(rssSources = settings.rssSources.filter { it.url != s.url }))
                                }) { Text("移除") }
                            }
                        }
                        if (settings.rssSources.isEmpty()) {
                            EmptyHint("暂无新闻源，请在下方添加")
                        }
                        Text("添加新闻源", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
                        OutlinedTextField(newSourceName, { newSourceName = it }, Modifier.fillMaxWidth(), label = { Text("名称") }, singleLine = true)
                        OutlinedTextField(newSourceUrl, { newSourceUrl = it }, Modifier.fillMaxWidth(), label = { Text("RSS 地址") }, singleLine = true)
                        Button(onClick = {
                            if (newSourceName.isNotBlank() && newSourceUrl.startsWith("http")) {
                                vm.saveSettings(
                                    settings.copy(rssSources = settings.rssSources + RssSource(newSourceName, newSourceUrl, "其他"))
                                )
                                newSourceName = ""; newSourceUrl = ""
                            }
                        }) { Text("添加") }
                    }
                }
            }
        }

        item { StaggerIn(4) { SectionHeader("✨ 体验") } }
        item {
            StaggerIn(5) {
                AnimatedCard {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("预见式返回动画", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            Text(
                                "支持 Android 14+ 的返回手势预览效果",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.predictiveBack,
                            onCheckedChange = { vm.saveSettings(settings.copy(predictiveBack = it)) }
                        )
                    }
                }
            }
        }

        item {
            Text(
                "Today · 单文件本地应用\n所有数据仅保存在你的手机中",
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
