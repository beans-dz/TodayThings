package com.today.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.util.concurrent.TimeUnit

object RssFetcher {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun fetch(source: RssSource): List<RawNews> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url(source.url)
                .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) TodayApp/1.0")
                .addHeader("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, */*")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
                val xml = resp.body?.string() ?: throw Exception("空内容")
                parse(xml, source)
            }
        }.getOrDefault(emptyList())
    }

    private fun parse(xml: String, source: RssSource): List<RawNews> {
        val out = ArrayList<RawNews>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(xml.reader())
        var inItem = false
        var title = ""
        var link = ""
        var desc = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                val tag = parser.name?.lowercase()
                when {
                    tag == "item" || tag == "entry" -> {
                        inItem = true; title = ""; link = ""; desc = ""
                    }
                    inItem && tag == "title" -> title = runCatching { parser.nextText() }.getOrDefault("")
                    inItem && tag == "link" -> {
                        val href = parser.getAttributeValue(null, "href")
                        link = href ?: runCatching { parser.nextText() }.getOrDefault("")
                    }
                    inItem && (tag == "description" || tag == "summary" || tag == "content") ->
                        desc = runCatching { parser.nextText() }.getOrDefault("")
                }
            } else if (event == XmlPullParser.END_TAG) {
                val tag = parser.name?.lowercase()
                if (inItem && (tag == "item" || tag == "entry")) {
                    if (title.isNotBlank()) {
                        out.add(RawNews(title.trim(), link.trim(), source.name, source.category, desc.trim()))
                    }
                    inItem = false
                }
            }
            event = parser.next()
        }
        return out
    }
}
