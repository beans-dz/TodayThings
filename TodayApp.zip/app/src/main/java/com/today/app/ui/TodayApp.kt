package com.today.app.ui

import android.app.Activity
import androidx.activity.BackEventCompat
import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.today.app.ui.screens.SettingsScreen
import com.today.app.ui.screens.ThingsScreen
import com.today.app.ui.screens.TodayScreen
import com.today.app.ui.theme.TodayTheme

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun TodayApp(vm: AppViewModel = viewModel()) {
    TodayTheme {
        val nav = rememberNavController()
        val settings by vm.settings.collectAsStateWithLifecycle()
        val backProgress = remember { mutableFloatStateOf(0f) }
        val context = LocalContext.current

        if (settings.predictiveBack) {
            PredictiveBackHandler(enabled = true) { events ->
                var popped = false
                try {
                    events.collect { ev ->
                        backProgress.floatValue = ev.progress
                        if (ev.progress > 0.5f && !popped) {
                            popped = true
                            if (!nav.popBackStack()) {
                                (context as? Activity)?.finish()
                            }
                        }
                    }
                } finally {
                    backProgress.floatValue = 0f
                }
            }
        }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = { TodayBottomBar(nav) }
        ) { padding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .graphicsLayer {
                        val p = backProgress.floatValue
                        scaleX = 1f - p * 0.08f
                        scaleY = 1f - p * 0.08f
                        alpha = 1f - p * 0.25f
                    }
            ) {
                NavHost(
                    navController = nav,
                    startDestination = "today",
                    modifier = Modifier.fillMaxSize(),
                    enterTransition = {
                        fadeIn(tween(260)) +
                            slideInHorizontally(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { it / 6 } +
                            scaleIn(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow), initialScale = 0.94f)
                    },
                    exitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(200)) { -it / 12 } },
                    popEnterTransition = { fadeIn(tween(220)) + slideInHorizontally(tween(240)) { -it / 12 } },
                    popExitTransition = {
                        fadeOut(tween(180)) +
                            slideOutHorizontally(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { it / 6 }
                    }
                ) {
                    composable("today") { TodayScreen(vm) }
                    composable("things") { ThingsScreen(vm) }
                    composable("settings") { SettingsScreen(vm) }
                }
            }
        }
    }
}

@Composable
fun TodayBottomBar(nav: NavHostController) {
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val items = listOf(
        Triple("today", "Today", Icons.Filled.DateRange),
        Triple("things", "Things", Icons.Filled.CheckCircle),
        Triple("settings", "Settings", Icons.Filled.Settings)
    )
    Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f), tonalElevation = 4.dp) {
        NavigationBar(containerColor = Color.Transparent, tonalElevation = 0.dp) {
            items.forEach { (route, label, icon) ->
                val selected = current == route
                val scale by animateFloatAsState(
                    targetValue = if (selected) 1.12f else 1f,
                    animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                    label = "iconScale"
                )
                NavigationBarItem(
                    selected = selected,
                    onClick = {
                        nav.navigate(route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            icon,
                            contentDescription = label,
                            modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
                        )
                    },
                    label = { Text(label) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }
    }
}
