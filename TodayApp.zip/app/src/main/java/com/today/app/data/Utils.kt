package com.today.app.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

fun todayStr(): String = LocalDate.now().toString()

fun parseDate(s: String): LocalDate = runCatching { LocalDate.parse(s) }.getOrElse { LocalDate.now() }

fun daysUntil(date: String): Long = ChronoUnit.DAYS.between(LocalDate.now(), parseDate(date))

fun dateLabel(s: String): String {
    val d = parseDate(s)
    return d.format(DateTimeFormatter.ofPattern("M月d日 EEE", Locale.CHINA))
}

fun weekdayCN(): String {
    val map = mapOf(
        1 to "星期一", 2 to "星期二", 3 to "星期三", 4 to "星期四",
        5 to "星期五", 6 to "星期六", 7 to "星期日"
    )
    return map[LocalDate.now().dayOfWeek.value] ?: ""
}

fun fullDateCN(): String {
    val d = LocalDate.now()
    return "${d.year}年${d.monthValue}月${d.dayOfMonth}日 ${weekdayCN()}"
}
