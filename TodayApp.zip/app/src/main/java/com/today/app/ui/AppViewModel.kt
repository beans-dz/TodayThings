package com.today.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.today.app.data.AppSettings
import com.today.app.data.BriefingService
import com.today.app.data.Countdown
import com.today.app.data.DailyBriefing
import com.today.app.data.DeepSeekClient
import com.today.app.data.Goal
import com.today.app.data.HealthService
import com.today.app.data.NewsItem
import com.today.app.data.Repo
import com.today.app.data.Task
import com.today.app.data.WeatherData
import com.today.app.data.WeatherService
import com.today.app.data.todayStr
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val settings: StateFlow<AppSettings> = Repo.settingsFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val tasks: StateFlow<List<Task>> = Repo.tasksFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val goals: StateFlow<List<Goal>> = Repo.goalsFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val countdowns: StateFlow<List<Countdown>> = Repo.countdownsFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _briefing = MutableStateFlow<DailyBriefing?>(null)
    val briefing: StateFlow<DailyBriefing?> = _briefing
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _weather = MutableStateFlow<WeatherData?>(null)
    val weather: StateFlow<WeatherData?> = _weather
    private val _weatherLoading = MutableStateFlow(false)
    val weatherLoading: StateFlow<Boolean> = _weatherLoading

    private val _steps = MutableStateFlow<Long?>(null)
    val steps: StateFlow<Long?> = _steps
    private val _sleepMinutes = MutableStateFlow<Long?>(null)
    val sleepMinutes: StateFlow<Long?> = _sleepMinutes
    private val _healthLoading = MutableStateFlow(false)
    val healthLoading: StateFlow<Boolean> = _healthLoading

    private val _newsSummaries = MutableStateFlow<Map<String, String>>(emptyMap())
    val newsSummaries: StateFlow<Map<String, String>> = _newsSummaries
    private val _summarizing = MutableStateFlow<Set<String>>(emptySet())
    val summarizing: StateFlow<Set<String>> = _summarizing

    init {
        viewModelScope.launch {
            _briefing.value = Repo.briefingFlow().first()
            val b = _briefing.value
            if (b == null || b.date != todayStr()) {
                refreshBriefing()
            }
            refreshWeather()
            refreshHealth()
        }
    }

    fun refreshBriefing() {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                val b = BriefingService.generate()
                Repo.saveBriefing(b)
                _briefing.value = b
            } catch (e: Exception) {
                _error.value = e.message ?: "生成失败"
            }
            _loading.value = false
        }
    }

    fun refreshWeather() {
        if (_weatherLoading.value) return
        viewModelScope.launch {
            _weatherLoading.value = true
            val s = settings.value
            _weather.value = WeatherService.get(s.city.ifBlank { null })
            _weatherLoading.value = false
        }
    }

    fun refreshHealth() {
        if (_healthLoading.value) return
        viewModelScope.launch {
            _healthLoading.value = true
            val ctx = getApplication<Application>()
            val raw = HealthService.readTodayStepsRaw(ctx)
            if (raw != null) {
                val (base, date) = Repo.stepBaseOnce()
                val today = todayStr()
                if (date != today) {
                    Repo.saveStepBase(raw, today)
                    _steps.value = 0L
                } else {
                    _steps.value = (raw - base).coerceAtLeast(0L)
                }
            }
            _sleepMinutes.value = HealthService.readSleepMinutes(ctx)
            _healthLoading.value = false
        }
    }

    fun summarizeNews(item: NewsItem) {
        val key = item.title
        if (key in _summarizing.value || _newsSummaries.value.containsKey(key)) return
        viewModelScope.launch {
            _summarizing.value = _summarizing.value + key
            val s = settings.value
            val result = if (s.apiKey.isBlank()) {
                "请先在 Settings 配置 AI Key"
            } else {
                try {
                    DeepSeekClient.chat(
                        s.baseUrl, s.apiKey, s.model,
                        "你是新闻助手，用中文一句话总结新闻要点，不超过60字，客观简洁，只输出总结本身。",
                        "新闻标题：${item.title}\n" + if (item.summary.isNotBlank()) "已有摘要：${item.summary}" else ""
                    )
                } catch (e: Exception) {
                    "总结失败：${e.message}"
                }
            }
            _newsSummaries.value = _newsSummaries.value + (key to result)
            _summarizing.value = _summarizing.value - key
        }
    }

    fun saveSettings(s: AppSettings) {
        viewModelScope.launch { Repo.saveSettings(s) }
    }

    fun addTask(title: String, time: String) {
        val list = tasks.value.toMutableList()
        list.add(0, Task(title = title.trim(), date = todayStr(), time = time.trim()))
        persistTasks(list)
    }

    fun toggleTask(id: String) {
        persistTasks(tasks.value.map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    fun deleteTask(id: String) {
        persistTasks(tasks.value.filter { it.id != id })
    }

    private fun persistTasks(list: List<Task>) {
        viewModelScope.launch { Repo.saveTasks(list) }
    }

    fun addGoal(title: String) {
        val list = goals.value.toMutableList()
        list.add(Goal(title = title.trim()))
        viewModelScope.launch { Repo.saveGoals(list) }
    }

    fun toggleGoalToday(id: String) {
        val t = todayStr()
        val list = goals.value.map { g ->
            if (g.id == id) {
                val set = g.checkedDates.toMutableSet()
                if (t in set) set.remove(t) else set.add(t)
                g.copy(checkedDates = set)
            } else g
        }
        viewModelScope.launch { Repo.saveGoals(list) }
    }

    fun deleteGoal(id: String) {
        viewModelScope.launch { Repo.saveGoals(goals.value.filter { it.id != id }) }
    }

    fun addCountdown(title: String, date: String) {
        val list = countdowns.value.toMutableList()
        list.add(Countdown(title = title.trim(), date = date))
        viewModelScope.launch { Repo.saveCountdowns(list) }
    }

    fun deleteCountdown(id: String) {
        viewModelScope.launch { Repo.saveCountdowns(countdowns.value.filter { it.id != id }) }
    }
}
