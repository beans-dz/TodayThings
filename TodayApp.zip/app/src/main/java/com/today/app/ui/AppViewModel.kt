package com.today.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.today.app.data.AppSettings
import com.today.app.data.BriefingService
import com.today.app.data.Countdown
import com.today.app.data.DailyBriefing
import com.today.app.data.Goal
import com.today.app.data.Repo
import com.today.app.data.Task
import com.today.app.data.todayStr
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val settings: StateFlow<AppSettings> = Repo.settingsFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val tasks: StateFlow<List<Task>> = Repo.tasksFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val goals: StateFlow<List<Goal>> = Repo.goalsFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val countdowns: StateFlow<List<Countdown>> = Repo.countdownsFlow()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _briefing = MutableStateFlow<DailyBriefing?>(null)
    val briefing: StateFlow<DailyBriefing?> = _briefing
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        viewModelScope.launch {
            _briefing.value = Repo.briefingFlow().first()
            val b = _briefing.value
            if (b == null || b.date != todayStr()) {
                refreshBriefing()
            }
        }
    }

    fun refreshBriefing() {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            runCatching {
                val b = BriefingService.generate()
                Repo.saveBriefing(b)
                _briefing.value = b
            }.onFailure { e ->
                _error.value = e.message ?: "生成失败"
            }
            _loading.value = false
        }
    }

    fun saveSettings(s: AppSettings) {
        viewModelScope.launch { Repo.saveSettings(s) }
    }

    fun addTask(title: String, time: String) {
        val list = tasks.value.toMutableList()
        list.add(0, Task(title = title.trim(), date = todayStr(), time = time.trim()))
        persistTasks(list)
    }

    fun toggleTask(id: String) {
        persistTasks(tasks.value.map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    fun deleteTask(id: String) {
        persistTasks(tasks.value.filter { it.id != id })
    }

    private fun persistTasks(list: List<Task>) {
        viewModelScope.launch { Repo.saveTasks(list) }
    }

    fun addGoal(title: String, icon: String) {
        val list = goals.value.toMutableList()
        list.add(Goal(title = title.trim(), icon = icon.ifBlank { "������" }))
        viewModelScope.launch { Repo.saveGoals(list) }
    }

    fun toggleGoalToday(id: String) {
        val t = todayStr()
        val list = goals.value.map { g ->
            if (g.id == id) {
                val set = g.checkedDates.toMutableSet()
                if (t in set) set.remove(t) else set.add(t)
                g.copy(checkedDates = set)
            } else g
        }
        viewModelScope.launch { Repo.saveGoals(list) }
    }

    fun deleteGoal(id: String) {
        viewModelScope.launch { Repo.saveGoals(goals.value.filter { it.id != id }) }
    }

    fun addCountdown(title: String, date: String, icon: String) {
        val list = countdowns.value.toMutableList()
        list.add(Countdown(title = title.trim(), date = date, icon = icon.ifBlank { "������" }))
        viewModelScope.launch { Repo.saveCountdowns(list) }
    }

    fun deleteCountdown(id: String) {
        viewModelScope.launch { Repo.saveCountdowns(countdowns.value.filter { it.id != id }) }
    }
}
