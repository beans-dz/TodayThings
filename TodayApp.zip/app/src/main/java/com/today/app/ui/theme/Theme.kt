package com.today.app.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1B6EF3)
val BlueSecondary = Color(0xFF3D8BFF)
val BlueTertiary = Color(0xFF00B8D9)
val LightBg = Color(0xFFF4F8FF)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAF1FE)
val LightOnBg = Color(0xFF0C1B33)
val DarkBg = Color(0xFF070D1A)
val DarkSurface = Color(0xFF0F1728)
val DarkSurfaceVariant = Color(0xFF1A2740)
val DarkOnBg = Color(0xFFE4EDFF)

private val LightColors = lightColorScheme(
    primary = BluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9E6FF),
    onPrimaryContainer = Color(0xFF0A2E66),
    secondary = BlueSecondary,
    onSecondary = Color.White,
    tertiary = BlueTertiary,
    background = LightBg,
    onBackground = LightOnBg,
    surface = LightSurface,
    onSurface = LightOnBg,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF3D4C66),
    outline = Color(0xFFB9C6E0),
    error = Color(0xFFE5484D)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7BA8FF),
    onPrimary = Color(0xFF06265C),
    primaryContainer = Color(0xFF163A80),
    onPrimaryContainer = Color(0xFFD9E6FF),
    secondary = Color(0xFF8FB6FF),
    onSecondary = Color(0xFF0B2A5A),
    tertiary = Color(0xFF5ED4E8),
    background = DarkBg,
    onBackground = DarkOnBg,
    surface = DarkSurface,
    onSurface = DarkOnBg,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF9FB0D0),
    outline = Color(0xFF33466B),
    error = Color(0xFFFF8A8A)
)

@Composable
fun TodayTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val bg by animateColorAsState(
        targetValue = if (dark) DarkBg else LightBg,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "themeBg"
    )
    val colors = if (dark) DarkColors else LightColors
    MaterialTheme(colorScheme = colors.copy(background = bg), content = content)
}
