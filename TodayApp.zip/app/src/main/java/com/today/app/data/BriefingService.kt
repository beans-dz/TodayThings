package com.today.app.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

object BriefingService {

    suspend fun generate(): DailyBriefing {
        val settings = Repo.settingsOnce()
        val today = todayStr()

        // 1. 抓取并整理新闻
        val allNews = coroutineScope {
            settings.rssSources.map { s -> async { RssFetcher.fetch(s) } }.awaitAll().flatten()
        }
        val seen = HashSet<String>()
        val dedup = allNews.filter { it.title.isNotBlank() && seen.add(it.title.trim().lowercase()) }
        val politics = dedup.filter { it.category == "时政" }.take(settings.politicsCount)
        val others = dedup.filter { it.category != "时政" }.take(settings.otherCount)
        val selected = politics + others

        // 2. 本地计算：今日待办 + 昨日目标
        val tasks = Repo.tasksOnce().filter { it.date == today }
        val goals = Repo.goalsOnce()
        val yesterday = LocalDate.now().minusDays(1).toString()
        val yDone = goals.filter { yesterday in it.checkedDates }.map { it.title }
        val yMiss = goals.filter { yesterday !in it.checkedDates }.map { it.title }
        val ySummaryLocal = buildString {
            append("昨日目标完成 ${yDone.size}/${goals.size}")
            if (yMiss.isNotEmpty()) append("，未完成：${yMiss.joinToString("、")}")
        }
        val planLocal = if (tasks.isEmpty()) "今日暂无安排" else tasks.sortedBy { it.time }
            .joinToString("\n") { t -> (if (t.time.isBlank()) "" else "${t.time} ") + t.title + (if (t.done) "（已完成）" else "") }

        // 3. AI 生成简报
        if (settings.apiKey.isNotBlank()) {
            val sys = "你是一个专业、克制的中文个人助理，负责生成《今日简报》。" +
                "你必须只输出一个合法的 JSON 对象，不要输出任何解释、markdown 或代码块。" +
                "JSON 字段：greeting（结合日期的一句问候）、yesterdaySummary（一句话总结昨日目标情况，客观简洁）、" +
                "todayPlan（今日主要事项整理，按时间排序，用换行分隔的短句，无事则写“今日暂无安排”）、" +
                "news（数组，元素：title 保持原标题不变、summary 一句话中文摘要30字内、category 值只能为“时政”或“其他”、" +
                "interested 布尔值，判断是否值得用户阅读原文，最多标 6 条 true）。严禁虚构，只基于给定信息。"
            val newsBlock = selected.mapIndexed { i, n ->
                "${i + 1}. [${n.category}] ${n.title}（来源：${n.source}）"
            }.joinToString("\n")
            val user = "今天是${fullDateCN()}。\n今日待办：\n" +
                (if (tasks.isEmpty()) "无" else tasks.joinToString("\n") { "- " + it.title + (if (it.time.isBlank()) "" else " ${it.time}") }) +
                "\n昨日目标：${ySummaryLocal}\n今日新闻（共${selected.size}条）：\n$newsBlock"

            return runCatching {
                val resp = DeepSeekClient.chat(settings.baseUrl, settings.apiKey, settings.model, sys, user)
                parseBriefing(resp, today, selected, ySummaryLocal, planLocal)
            }.getOrElse { fallback(today, selected, ySummaryLocal, planLocal) }
        }
        return fallback(today, selected, ySummaryLocal, planLocal)
    }

    private fun parseBriefing(
        resp: String,
        today: String,
        news: List<RawNews>,
        ySummary: String,
        planLocal: String
    ): DailyBriefing {
        val start = resp.indexOf('{')
        val end = resp.lastIndexOf('}')
        if (start < 0 || end <= start) return fallback(today, news, ySummary, planLocal)
        return runCatching {
            val jo = JSONObject(resp.substring(start, end + 1))
            val arr = jo.optJSONArray("news")
            val items = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val t = o.optString("title").trim()
                val orig = news.firstOrNull { it.title.trim() == t }
                    ?: news.firstOrNull { it.title.contains(t) || t.contains(it.title) }
                NewsItem(
                    title = t.ifBlank { orig?.title ?: "" },
                    link = orig?.link ?: "",
                    source = orig?.source ?: "",
                    category = o.optString("category", orig?.category ?: "时政"),
                    summary = o.optString("summary"),
                    interested = o.optBoolean("interested", false)
                )
            }
            DailyBriefing(
                date = today,
                greeting = jo.optString("greeting", ""),
                yesterdaySummary = jo.optString("yesterdaySummary", ySummary),
                todayPlan = jo.optString("todayPlan", planLocal),
                news = items.ifEmpty { news.map { NewsItem(it.title, it.link, it.source, it.category, it.description.take(80)) } },
                generatedAt = System.currentTimeMillis()
            )
        }.getOrDefault(fallback(today, news, ySummary, planLocal))
    }

    private fun fallback(today: String, news: List<RawNews>, ySummary: String, planLocal: String): DailyBriefing {
        val h = LocalTime.now().hour
        val greeting = when {
            h < 6 -> "夜深了，注意休息"
            h < 9 -> "早上好，开启新的一天"
            h < 12 -> "上午好"
            h < 14 -> "中午好"
            h < 18 -> "下午好"
            else -> "晚上好"
        }
        return DailyBriefing(
            date = today,
            greeting = "$greeting，今天也要加油。",
            yesterdaySummary = ySummary,
            todayPlan = planLocal,
            news = news.map { NewsItem(it.title, it.link, it.source, it.category, "") },
            generatedAt = System.currentTimeMillis()
        )
    }
}
