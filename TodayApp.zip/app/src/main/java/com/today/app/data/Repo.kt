package com.today.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "today_prefs")

object Repo {
    lateinit var ctx: Context
        private set

    fun init(context: Context) {
        ctx = context.applicationContext
    }

    private val K_API = stringPreferencesKey("api_key")
    private val K_BASE = stringPreferencesKey("base_url")
    private val K_MODEL = stringPreferencesKey("model")
    private val K_POLITICS = stringPreferencesKey("politics_count")
    private val K_OTHER = stringPreferencesKey("other_count")
    private val K_RSS = stringPreferencesKey("rss_sources")
    private val K_PREDICTIVE = stringPreferencesKey("predictive_back")
    private val K_TASKS = stringPreferencesKey("tasks")
    private val K_GOALS = stringPreferencesKey("goals")
    private val K_COUNTDOWNS = stringPreferencesKey("countdowns")
    private val K_BRIEFING = stringPreferencesKey("briefing")

    fun settingsFlow(): Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            apiKey = p[K_API] ?: "",
            baseUrl = p[K_BASE] ?: "https://api.deepseek.com",
            model = p[K_MODEL] ?: "deepseek-chat",
            politicsCount = (p[K_POLITICS] ?: "15").toIntOrNull() ?: 15,
            otherCount = (p[K_OTHER] ?: "5").toIntOrNull() ?: 5,
            rssSources = decodeRss(p[K_RSS]),
            predictiveBack = p[K_PREDICTIVE] != "false"
        )
    }

    suspend fun settingsOnce(): AppSettings = settingsFlow().first()

    suspend fun saveSettings(s: AppSettings) {
        ctx.dataStore.edit { p ->
            p[K_API] = s.apiKey
            p[K_BASE] = s.baseUrl
            p[K_MODEL] = s.model
            p[K_POLITICS] = s.politicsCount.toString()
            p[K_OTHER] = s.otherCount.toString()
            p[K_RSS] = encodeRss(s.rssSources)
            p[K_PREDICTIVE] = if (s.predictiveBack) "true" else "false"
        }
    }

    fun tasksFlow(): Flow<List<Task>> = ctx.dataStore.data.map { decodeTasks(it[K_TASKS]) }
    fun goalsFlow(): Flow<List<Goal>> = ctx.dataStore.data.map { decodeGoals(it[K_GOALS]) }
    fun countdownsFlow(): Flow<List<Countdown>> = ctx.dataStore.data.map { decodeCountdowns(it[K_COUNTDOWNS]) }
    fun briefingFlow(): Flow<DailyBriefing?> = ctx.dataStore.data.map { decodeBriefing(it[K_BRIEFING]) }

    suspend fun tasksOnce(): List<Task> = tasksFlow().first()
    suspend fun saveTasks(list: List<Task>) { ctx.dataStore.edit { it[K_TASKS] = encodeTasks(list) } }
    suspend fun saveGoals(list: List<Goal>) { ctx.dataStore.edit { it[K_GOALS] = encodeGoals(list) } }
    suspend fun saveCountdowns(list: List<Countdown>) { ctx.dataStore.edit { it[K_COUNTDOWNS] = encodeCountdowns(list) } }
    suspend fun saveBriefing(b: DailyBriefing) { ctx.dataStore.edit { it[K_BRIEFING] = encodeBriefing(b) } }

    private fun encodeRss(list: List<RssSource>): String {
        val a = JSONArray()
        list.forEach { s -> a.put(JSONObject().put("name", s.name).put("url", s.url).put("category", s.category)) }
        return a.toString()
    }

    private fun decodeRss(json: String?): List<RssSource> {
        if (json.isNullOrBlank()) return defaultRssSources
        return runCatching {
            val a = JSONArray(json)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                RssSource(o.optString("name"), o.optString("url"), o.optString("category", "其他"))
            }
        }.getOrDefault(defaultRssSources)
    }

    private fun encodeTasks(list: List<Task>): String {
        val a = JSONArray()
        list.forEach { t ->
            a.put(JSONObject().put("id", t.id).put("title", t.title).put("date", t.date).put("time", t.time).put("done", t.done))
        }
        return a.toString()
    }

    private fun decodeTasks(json: String?): List<Task> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(json)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Task(o.optString("id"), o.optString("title"), o.optString("date"), o.optString("time"), o.optBoolean("done"))
            }
        }.getOrDefault(emptyList())
    }

    private fun encodeGoals(list: List<Goal>): String {
        val a = JSONArray()
        list.forEach { g ->
            val days = JSONArray()
            g.checkedDates.forEach { days.put(it) }
            a.put(JSONObject().put("id", g.id).put("title", g.title).put("icon", g.icon).put("checkedDates", days))
        }
        return a.toString()
    }

    private fun decodeGoals(json: String?): List<Goal> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(json)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val days = o.optJSONArray("checkedDates")
                val set = if (days == null) emptySet() else (0 until days.length()).map { days.getString(it) }.toSet()
                Goal(o.optString("id"), o.optString("title"), o.optString("icon", "������"), set)
            }
        }.getOrDefault(emptyList())
    }

    private fun encodeCountdowns(list: List<Countdown>): String {
        val a = JSONArray()
        list.forEach { c -> a.put(JSONObject().put("id", c.id).put("title", c.title).put("date", c.date).put("icon", c.icon)) }
        return a.toString()
    }

    private fun decodeCountdowns(json: String?): List<Countdown> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val a = JSONArray(json)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Countdown(o.optString("id"), o.optString("title"), o.optString("date"), o.optString("icon", "������"))
            }
        }.getOrDefault(emptyList())
    }

    private fun encodeBriefing(b: DailyBriefing): String {
        val newsArr = JSONArray()
        b.news.forEach { n ->
            newsArr.put(
                JSONObject().put("title", n.title).put("link", n.link).put("source", n.source)
                    .put("category", n.category).put("summary", n.summary).put("interested", n.interested)
            )
        }
        return JSONObject()
            .put("date", b.date).put("greeting", b.greeting)
            .put("yesterdaySummary", b.yesterdaySummary).put("todayPlan", b.todayPlan)
            .put("generatedAt", b.generatedAt).put("news", newsArr)
            .toString()
    }

    private fun decodeBriefing(json: String?): DailyBriefing? {
        if (json.isNullOrBlank()) return null
        return runCatching {
            val o = JSONObject(json)
            val arr = o.optJSONArray("news")
            val news = if (arr == null) emptyList() else (0 until arr.length()).map { i ->
                val n = arr.getJSONObject(i)
                NewsItem(
                    n.optString("title"), n.optString("link"), n.optString("source"),
                    n.optString("category", "时政"), n.optString("summary"), n.optBoolean("interested")
                )
            }
            DailyBriefing(
                o.optString("date"), o.optString("greeting"), o.optString("yesterdaySummary"),
                o.optString("todayPlan"), news, o.optLong("generatedAt", System.currentTimeMillis())
            )
        }.getOrNull()
    }
}
