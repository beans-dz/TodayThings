package com.today.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object DeepSeekClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    suspend fun chat(baseUrl: String, apiKey: String, model: String, system: String, user: String): String =
        withContext(Dispatchers.IO) {
            val url = baseUrl.trimEnd('/') + "/chat/completions"
            val payload = JSONObject().apply {
                put("model", model)
                put("temperature", 0.3)
                put("stream", false)
                put("messages", JSONArray().apply {
                    put(JSONObject().put("role", "system").put("content", system))
                    put(JSONObject().put("role", "user").put("content", user))
                })
            }.toString()

            val req = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (!resp.isSuccessful) throw Exception("AI 请求失败 ${resp.code}: ${body.take(200)}")
                val jo = JSONObject(body)
                jo.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }

    suspend fun test(baseUrl: String, apiKey: String, model: String): Boolean =
        try {
            val r = chat(baseUrl, apiKey, model, "你只会回复两个字：正常", "测试连接")
            r.isNotBlank()
        } catch (e: Exception) {
            false
        }
}
