package com.today.app.data

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

object HealthService {

    suspend fun readTodayStepsRaw(ctx: Context): Long? = withContext(Dispatchers.IO) {
        try {
            val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return@withContext null
            suspendCancellableCoroutine { cont ->
                val listener = object : SensorEventListener {
                    override fun onSensorChanged(event: SensorEvent) {
                        sm.unregisterListener(this)
                        if (cont.isActive) cont.resume(event.values[0].toLong())
                    }

                    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
                }
                sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
                Handler(Looper.getMainLooper()).postDelayed({
                    sm.unregisterListener(listener)
                    if (cont.isActive) cont.resume(null)
                }, 3000)
                cont.invokeOnCancellation { sm.unregisterListener(listener) }
            }
        } catch (e: Exception) {
            null
        }
    }
}
