package com.today.app.data

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.temporal.ChronoUnit

object HealthService {

    suspend fun readTodayStepsRaw(ctx: Context): Long? = withContext(Dispatchers.IO) {
        try {
            val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return@withContext null
            suspendCancellableCoroutine { cont ->
                val listener = object : SensorEventListener {
                    override fun onSensorChanged(event: SensorEvent) {
                        sm.unregisterListener(this)
                        if (cont.isActive) cont.resume(event.values[0].toLong())
                    }

                    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
                }
                sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
                Handler(Looper.getMainLooper()).postDelayed({
                    sm.unregisterListener(listener)
                    if (cont.isActive) cont.resume(null)
                }, 3000)
                cont.invokeOnCancellation { sm.unregisterListener(listener) }
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun readSleepMinutes(ctx: Context): Long? = withContext(Dispatchers.IO) {
        runCatching {
            val client = HealthConnectClient.getOrCreate(ctx)
            val now = Instant.now()
            val start = now.minus(1, ChronoUnit.DAYS)
            val request = ReadRecordsRequest(
                SleepSessionRecord::class,
                timeRangeFilter = TimeRangeFilter.between(start, now)
            )
            val response = client.readRecords(request)
            response.records.sumOf { r ->
                (r.endTime.toEpochMilli() - r.startTime.toEpochMilli()) / 60000
            }
        }.getOrNull()
    }

    fun openHealthSettings(ctx: Context) {
        runCatching {
            val intent = Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        }
    }
}
