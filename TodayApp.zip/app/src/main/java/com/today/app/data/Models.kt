package com.today.app.data

data class AppSettings(
    val apiKey: String = "",
    val baseUrl: String = "https://api.deepseek.com",
    val model: String = "deepseek-chat",
    val politicsCount: Int = 15,
    val otherCount: Int = 5,
    val rssSources: List<RssSource> = defaultRssSources,
    val predictiveBack: Boolean = true
)

data class RssSource(val name: String, val url: String, val category: String)

data class Task(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val time: String = "",
    val done: Boolean = false
)

data class Goal(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val icon: String = "������",
    val checkedDates: Set<String> = emptySet()
)

data class Countdown(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val icon: String = "������"
)

data class NewsItem(
    val title: String,
    val link: String = "",
    val source: String = "",
    val category: String = "时政",
    val summary: String = "",
    val interested: Boolean = false
)

data class DailyBriefing(
    val date: String,
    val greeting: String = "",
    val yesterdaySummary: String = "",
    val todayPlan: String = "",
    val news: List<NewsItem> = emptyList(),
    val generatedAt: Long = System.currentTimeMillis()
)

data class RawNews(
    val title: String,
    val link: String,
    val source: String,
    val category: String,
    val description: String = ""
)

val defaultRssSources = listOf(
    RssSource("人民网·时政", "http://www.people.com.cn/rss/politics.xml", "时政"),
    RssSource("人民网·国际", "http://www.people.com.cn/rss/world.xml", "时政"),
    RssSource("BBC中文", "https://feeds.bbci.co.uk/zhongwen/simp/rss.xml", "时政"),
    RssSource("德国之声中文", "https://rss.dw.com/rdf/rss-chi-all", "时政"),
    RssSource("IT之家", "https://www.ithome.com/rss/", "其他"),
    RssSource("少数派", "https://sspai.com/feed", "其他"),
    RssSource("虎嗅", "https://www.huxiu.com/rss/0.xml", "其他"),
    RssSource("知乎每日精选", "https://www.zhihu.com/rss", "其他")
)
