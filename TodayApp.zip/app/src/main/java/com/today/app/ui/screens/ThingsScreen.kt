package com.today.app.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.today.app.data.Countdown
import com.today.app.data.Goal
import com.today.app.data.Task
import com.today.app.data.dateLabel
import com.today.app.data.daysUntil
import com.today.app.data.todayStr
import com.today.app.ui.AppViewModel
import com.today.app.ui.components.AnimatedCard
import com.today.app.ui.components.EmptyHint
import com.today.app.ui.components.SectionHeader
import com.today.app.ui.components.StaggerIn
import java.time.Instant
import java.time.ZoneId

@Composable
fun ThingsScreen(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val goals by vm.goals.collectAsStateWithLifecycle()
    val countdowns by vm.countdowns.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Things", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }

        item { StaggerIn(0) { SectionHeader("倒计时") } }
        if (countdowns.isEmpty()) {
            item { StaggerIn(1) { EmptyHint("添加考试、生日、纪念日等关键日期") } }
        } else {
            itemsIndexed(countdowns, key = { _, c -> c.id }) { i, c ->
                StaggerIn(i.coerceAtMost(8)) { CountdownCard(c) { vm.deleteCountdown(c.id) } }
            }
        }
        item { StaggerIn(2) { CountdownInput { title, date -> vm.addCountdown(title, date) } } }

        item { StaggerIn(3) { SectionHeader("每日目标") } }
        if (goals.isEmpty()) {
            item { StaggerIn(4) { EmptyHint("设定几个每天坚持的小目标，打卡会积累成就") } }
        } else {
            itemsIndexed(goals, key = { _, g -> g.id }) { i, g ->
                StaggerIn(i.coerceAtMost(8)) { GoalCard(g, onToggle = { vm.toggleGoalToday(g.id) }, onDelete = { vm.deleteGoal(g.id) }) }
            }
        }
        item { StaggerIn(5) { GoalInput { title -> vm.addGoal(title) } } }

        item { StaggerIn(6) { SectionHeader("今日待办") } }
        val todayTasks = tasks.filter { it.date == todayStr() }
        if (todayTasks.isEmpty()) {
            item { StaggerIn(7) { EmptyHint("今天还没有安排") } }
        } else {
            itemsIndexed(todayTasks, key = { _, t -> t.id }) { i, t ->
                StaggerIn(i.coerceAtMost(8)) { TaskRow(t, onToggle = { vm.toggleTask(t.id) }, onDelete = { vm.deleteTask(t.id) }) }
            }
        }
        item { StaggerIn(8) { TaskInput { title, time -> vm.addTask(title, time) } } }
    }
}

@Composable
private fun CountdownCard(c: Countdown, onDelete: () -> Unit) {
    val days = daysUntil(c.date)
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.DateRange,
                null,
                Modifier.size(28.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(dateLabel(c.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                if (days > 0) "${days}天" else if (days == 0L) "就是今天" else "已过${-days}天",
                style = MaterialTheme.typography.titleMedium,
                color = if (days in 0L..3L) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(6.dp))
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CountdownInput(onAdd: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }
    AnimatedCard {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                title, { title = it }, Modifier.fillMaxWidth(),
                placeholder = { Text("名称，如：高考") }, singleLine = true
            )
            OutlinedTextField(
                value = if (date.isBlank()) "" else dateLabel(date),
                onValueChange = {},
                readOnly = true,
                modifier = Modifier.fillMaxWidth().clickable { showPicker = true },
                placeholder = { Text("点击选择日期") },
                singleLine = true,
                trailingIcon = { Icon(Icons.Filled.DateRange, null) }
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    if (title.isNotBlank() && date.isNotBlank()) {
                        onAdd(title, date)
                        title = ""
                        date = ""
                    }
                }) { Text("添加") }
            }
        }
    }
    if (showPicker) {
        val pickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { millis ->
                        date = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                    }
                    showPicker = false
                }) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("取消") }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
private fun GoalCard(g: Goal, onToggle: () -> Unit, onDelete: () -> Unit) {
    val checked = todayStr() in g.checkedDates
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val scale by animateFloatAsState(
                targetValue = if (checked) 1f else 0.9f,
                animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                label = "goalScale"
            )
            Box(
                Modifier
                    .size(40.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(CircleShape)
                    .background(if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (checked) Icon(Icons.Filled.Check, "打卡", tint = Color.White, modifier = Modifier.size(22.dp))
                else Text(g.title.take(1), color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    g.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    "已打卡 ${g.checkedDates.size} 天",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun GoalInput(onAdd: (String) -> Unit) {
    var title by remember { mutableStateOf("") }
    AnimatedCard {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                title, { title = it }, Modifier.weight(1f),
                placeholder = { Text("目标，如：跑步 30 分钟") }, singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    onAdd(title)
                    title = ""
                }
            }) { Text("添加") }
        }
    }
}

@Composable
private fun TaskRow(t: Task, onToggle: () -> Unit, onDelete: () -> Unit) {
    val scale by animateFloatAsState(
        targetValue = if (t.done) 1.05f else 1f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "taskScale"
    )
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(14.dp).graphicsLayer { scaleX = scale; scaleY = scale },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (t.done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (t.done) Icon(Icons.Filled.Check, null, Modifier.size(16.dp), tint = Color.White)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (t.done) FontWeight.Normal else FontWeight.Medium,
                    color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                if (t.time.isNotBlank()) {
                    Text(t.time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun TaskInput(onAdd: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    AnimatedCard {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(time, { time = it }, Modifier.width(86.dp), placeholder = { Text("时间") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(title, { title = it }, Modifier.weight(1f), placeholder = { Text("待办，如：9点开会") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    onAdd(title, time)
                    title = ""
                    time = ""
                }
            }) { Text("添加") }
        }
    }
}
