package com.today.app.ui.screens

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.today.app.data.NewsItem
import com.today.app.data.fullDateCN
import com.today.app.data.todayStr
import com.today.app.ui.AppViewModel
import com.today.app.ui.components.AnimatedCard
import com.today.app.ui.components.EmptyHint
import com.today.app.ui.components.ErrorCard
import com.today.app.ui.components.SectionHeader
import com.today.app.ui.components.ShimmerBox
import com.today.app.ui.components.StaggerIn
import com.today.app.ui.components.openLink
import kotlinx.coroutines.launch

@Composable
fun TodayScreen(vm: AppViewModel) {
    val briefing by vm.briefing.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val rotation = remember { Animatable(0f) }
    val b = briefing

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        fullDateCN(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        if (b?.greeting.isNullOrBlank()) "你好 ������" else b?.greeting.orEmpty(),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = {
                    scope.launch {
                        launch { rotation.animateTo(rotation.value + 360f, tween(650)) }
                        vm.refreshBriefing()
                    }
                }) {
                    Icon(
                        Icons.Filled.Refresh,
                        "刷新简报",
                        Modifier.size(22.dp).graphicsLayer { rotationZ = rotation.value },
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        if (loading && b == null) {
            items(4) { i -> ShimmerBox(Modifier.fillMaxWidth().height((86 + i * 14).dp)) }
        } else {
            item { StaggerIn(0) { AnimatedCard { YesterdayCard(b?.yesterdaySummary) } } }
            item { StaggerIn(1) { AnimatedCard { TodayPlanCard(b?.todayPlan, tasks) } } }
            item { StaggerIn(2) { SectionHeader("今日新闻 · ${b?.news?.size ?: 0} 条") } }

            val news = b?.news.orEmpty()
            if (news.isEmpty() && !loading) {
                item {
                    StaggerIn(3) {
                        EmptyHint("还没有简报内容。点右上角刷新，或到 Settings 检查 AI Key 与新闻源")
                    }
                }
            } else {
                news.forEachIndexed { i, n ->
                    item(key = n.title + i) { StaggerIn(i.coerceAtMost(12)) { NewsCard(n, context) } }
                }
            }
        }

        if (error != null) {
            item { ErrorCard(error.orEmpty()) { vm.refreshBriefing() } }
        }
    }
}

@Composable
private fun YesterdayCard(text: String?) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("������", fontSize = 18.sp)
            Spacer(Modifier.width(6.dp))
            Text("昨日目标情况", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
        Text(
            text?.ifBlank { "暂无昨日记录" } ?: "暂无昨日记录",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TodayPlanCard(text: String?, tasks: List<com.today.app.data.Task>) {
    val today = tasks.filter { it.date == todayStr() }
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("������", fontSize = 18.sp)
            Spacer(Modifier.width(6.dp))
            Text("今日主要日常", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            if (today.isNotEmpty()) {
                Text(
                    "${today.count { it.done }}/${today.size} 完成",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
        Text(
            text?.ifBlank { "今日暂无安排" } ?: "今日暂无安排",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun NewsCard(n: NewsItem, context: Context) {
    AnimatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (n.category == "时政") MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f)
                ) {
                    Text(
                        n.category,
                        Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (n.category == "时政") MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.tertiary
                    )
                }
                if (n.source.isNotBlank()) {
                    Text(
                        " · ${n.source}",
                        Modifier.padding(start = 6.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(n.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (n.summary.isNotBlank()) {
                Text(
                    n.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (n.interested && n.link.isNotBlank()) {
                Row(
                    Modifier.clickable { openLink(context, n.link) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("查看原文", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        Icons.Filled.ArrowForward,
                        null,
                        Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
