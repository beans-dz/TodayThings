package com.today.app.ui.screens

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.today.app.data.DailyBriefing
import com.today.app.data.Goal
import com.today.app.data.NewsItem
import com.today.app.data.Task
import com.today.app.data.WeatherData
import com.today.app.data.fullDateCN
import com.today.app.data.todayStr
import com.today.app.ui.AppViewModel
import com.today.app.ui.components.AnimatedCard
import com.today.app.ui.components.EmptyHint
import com.today.app.ui.components.ErrorCard
import com.today.app.ui.components.SectionHeader
import com.today.app.ui.components.ShimmerBox
import com.today.app.ui.components.StaggerIn
import com.today.app.ui.components.openLink
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalTime

@Composable
fun TodayScreen(vm: AppViewModel) {
    val briefing by vm.briefing.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val goals by vm.goals.collectAsStateWithLifecycle()
    val weather by vm.weather.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val rotation = remember { Animatable(0f) }
    val b = briefing

    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalTime.now()
            delay(30_000)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Header(now, weather) {
                scope.launch {
                    launch { rotation.animateTo(rotation.value + 360f, tween(650)) }
                    vm.refreshBriefing()
                    vm.refreshWeather()
                }
            }
        }

        if (loading && b == null) {
            items(4) { i -> ShimmerBox(Modifier.fillMaxWidth().height((86 + i * 14).dp)) }
        } else {
            item { StaggerIn(0) { AISummaryCard(b) } }

            item { StaggerIn(1) { SectionHeader("今日目标") } }
            if (goals.isEmpty()) {
                item { StaggerIn(2) { EmptyHint("还没有目标，去 Things 页添加") } }
            } else {
                items(goals, key = { it.id }) { g ->
                    StaggerIn(2) { GoalQuickCard(g) { vm.toggleGoalToday(g.id) } }
                }
            }

            item { StaggerIn(3) { SectionHeader("今日待办") } }
            val todayTasks = tasks.filter { it.date == todayStr() }
            if (todayTasks.isEmpty()) {
                item { StaggerIn(4) { EmptyHint("今天还没有安排") } }
            } else {
                items(todayTasks, key = { it.id }) { t ->
                    StaggerIn(4) { TaskQuickRow(t, onToggle = { vm.toggleTask(t.id) }, onDelete = { vm.deleteTask(t.id) }) }
                }
            }

            item { StaggerIn(5) { SectionHeader("今日新闻 · ${b?.news?.size ?: 0} 条") } }
            val news = b?.news.orEmpty()
            if (news.isEmpty() && !loading) {
                item {
                    StaggerIn(6) {
                        EmptyHint("还没有新闻。点右上角刷新，或到 Settings 检查 AI Key 与新闻源")
                    }
                }
            } else {
                news.forEachIndexed { i, n ->
                    item(key = "news" + n.title + i) { StaggerIn(6) { NewsCard(n, context) } }
                }
            }
        }

        if (error != null) {
            item { ErrorCard(error.orEmpty()) { vm.refreshBriefing() } }
        }
    }
}

@Composable
private fun Header(now: LocalTime, weather: WeatherData?, onRefresh: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "${now.hour.toString().padStart(2, '0')}:${now.minute.toString().padStart(2, '0')}",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    fullDateCN(),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onRefresh) {
                Icon(
                    Icons.Filled.Refresh,
                    "刷新",
                    Modifier.size(22.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Info,
                    null,
                    Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        weather == null -> "天气获取中，下拉刷新重试"
                        weather.temp == null -> weather.desc
                        else -> {
                            val t = weather.temp
                            val tStr = if (t == t.toInt().toDouble()) t.toInt().toString() else String.format("%.1f", t)
                            buildString {
                                if (weather.city.isNotBlank()) append(weather.city + " ")
                                append("${weather.desc} ${tStr}°C")
                            }
                        }
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AISummaryCard(b: DailyBriefing?) {
    AnimatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.CheckCircle,
                    null,
                    Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    b?.greeting?.ifBlank { "今日简报" } ?: "今日简报",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            if (!b?.yesterdaySummary.isNullOrBlank()) {
                Text("昨日目标", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    b?.yesterdaySummary.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!b?.todayPlan.isNullOrBlank() && b?.todayPlan != "今日暂无安排") {
                Text("今日计划", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    b?.todayPlan.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )
            }
            if (!b?.focus.isNullOrBlank()) {
                Text("近期关注", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    b?.focus.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun GoalQuickCard(g: Goal, onToggle: () -> Unit) {
    val checked = todayStr() in g.checkedDates
    val scale by animateFloatAsState(
        targetValue = if (checked) 1f else 0.9f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "goalQuickScale"
    )
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(38.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(CircleShape)
                    .background(if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (checked) Icon(Icons.Filled.Check, "已打卡", Modifier.size(20.dp), tint = Color.White)
                else Text(g.title.take(1), color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Text(
                g.title,
                Modifier.weight(1f),
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (checked) FontWeight.Normal else FontWeight.Medium,
                color = if (checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            if (checked) {
                Icon(Icons.Filled.CheckCircle, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun TaskQuickRow(t: Task, onToggle: () -> Unit, onDelete: () -> Unit) {
    AnimatedCard {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (t.done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (t.done) Icon(Icons.Filled.Check, null, Modifier.size(14.dp), tint = Color.White)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (t.done) FontWeight.Normal else FontWeight.Medium,
                    color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                if (t.time.isNotBlank()) {
                    Text(t.time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            Icon(
                Icons.Filled.Close,
                "删除",
                Modifier.size(18.dp).clickable(onClick = onDelete),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun NewsCard(n: NewsItem, context: Context) {
    AnimatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (n.category == "时政") MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f)
                ) {
                    Text(
                        n.category,
                        Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (n.category == "时政") MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.tertiary
                    )
                }
                if (n.source.isNotBlank()) {
                    Text(
                        " · ${n.source}",
                        Modifier.padding(start = 6.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(n.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (n.summary.isNotBlank()) {
                Text(
                    n.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (n.interested && n.link.isNotBlank()) {
                Row(
                    Modifier.clickable { openLink(context, n.link) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("查看原文", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Filled.ArrowForward, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
